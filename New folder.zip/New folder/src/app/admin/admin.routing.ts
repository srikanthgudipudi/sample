import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AdminDashboardComponent } from 'src/app/admin-dashboard/admin-dashboard.component';
import { AuthGuard } from '../core/providers/auth.gaurd';
import { UserRegistrationComponent } from 'src/app/user-registration/user-registration.component';
import { CustomerRegistrationComponent } from 'src/app/customer-registration/customer-registration.component';
import { SearchCustomerComponent } from 'src/app/customer-registration/search-customer/search-customer.component';
import { RegisterCustomerComponent } from 'src/app/customer-registration/register-customer/register-customer.component';
import { SearchUserComponent } from 'src/app/user-registration/search-user/search-user.component';
import { CreateUserComponent } from 'src/app/user-registration/create-user/create-user.component';
import { ApprovalQueueComponent } from 'src/app/admin-dashboard/approval-queue/approval-queue.component';
import { RequestListComponent } from 'src/app/admin-dashboard/request-list/request-list.component';

const adminRoutes: Routes = [
    {
        path: 'ppcAdmin', component: AdminComponent, children: [
            {
                path: 'dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard], children: [
                    { path: 'approvalList', component: ApprovalQueueComponent },
                    { path: 'requestList', component: RequestListComponent },
                    { path: '', component: ApprovalQueueComponent },
                    { path: '', pathMatch: 'full', redirectTo: 'approvalList' },
                ]
            },
            // { path: 'customerRegistration', loadChildren: '../customer-registration/customer-registration.module#CustomerRegistrationModule', canActivate: [AuthGuard] },
            // {path:'customerRegistration' ,loadChildren: ()=>CustomerRegistrationModule},
            {
                path: 'customerRegistration', component: CustomerRegistrationComponent, canActivate: [AuthGuard], children: [
                    { path: 'searchCustomer', component: SearchCustomerComponent },
                    { path: 'registerCustomer', component: RegisterCustomerComponent },
                    { path: '', component: SearchCustomerComponent },
                    { path: '', pathMatch: 'full', redirectTo: 'search' },
                ]
            },
            {
                path: 'userRegistration', component: UserRegistrationComponent, canActivate: [AuthGuard], children: [
                    { path: 'searchUser', component: SearchUserComponent },
                    { path: 'createUser', component: CreateUserComponent },
                    { path: '', component: SearchUserComponent },
                    { path: '', pathMatch: 'full', redirectTo: 'searchUser' },
                ]
            },
            { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
            { path: '**', pathMatch: 'full', redirectTo: 'dashboard' }
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot
            (adminRoutes
            )
    ],
    exports: [
        RouterModule
    ]
})
export class AdminRouting { }
