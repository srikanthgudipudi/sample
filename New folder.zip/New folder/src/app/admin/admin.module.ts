import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ErrorMessageComponent } from 'src/app/core/directives/error-message/error.message.component';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';
import { AdminHeaderComponent } from '../admin-header/admin-header.component';
import { AdminSideMenuComponent } from 'src/app/admin-sidemenu/admin-sidemenu.component';
import { AdminDashboardComponent } from '../admin-dashboard/admin-dashboard.component';
import { CoreModule } from '../core/core.module';
import { SharedModule } from '../core/shared.module';
import { AdminComponent } from './admin.component';
import { RouterModule } from '@angular/router';
import { AdminRouting } from './admin.routing';
import { AdminFooterComponent } from 'src/app/admin-footer/admin-footer.component';
import { UserRegistrationComponent } from 'src/app/user-registration/user-registration.component';
import { CustomerRegistrationComponent } from 'src/app/customer-registration/customer-registration.component';
import { SearchCustomerComponent } from 'src/app/customer-registration/search-customer/search-customer.component';
import { RegisterCustomerComponent } from 'src/app/customer-registration/register-customer/register-customer.component';
import { CustomerSearchService } from 'src/app/core/services/customer-search.service';
import { SearchUserComponent } from 'src/app/user-registration/search-user/search-user.component';
import { CreateUserComponent } from 'src/app/user-registration/create-user/create-user.component';
import { ApprovalQueueComponent } from 'src/app/admin-dashboard/approval-queue/approval-queue.component';
import { RequestListComponent } from 'src/app/admin-dashboard/request-list/request-list.component';

@NgModule({
    declarations: [
        AdminHeaderComponent,
        AdminSideMenuComponent,
        AdminFooterComponent,
        AdminDashboardComponent,
        UserRegistrationComponent,
        CustomerRegistrationComponent,
        SearchCustomerComponent,
        RegisterCustomerComponent,
        SearchUserComponent,
        CreateUserComponent,
        ApprovalQueueComponent,
        RequestListComponent,
        ErrorMessageComponent,
        AdminComponent,
    ],
    imports: [
        CoreModule.forRoot(),
        SharedModule,
        RouterModule,
        AdminRouting
    ],
    providers:[
        CustomerSearchService
    ]
})
export class AdminModule { }
