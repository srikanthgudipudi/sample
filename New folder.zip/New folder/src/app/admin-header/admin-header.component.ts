import { Component, OnInit } from '@angular/core';
import { SidenavService } from '../core/services/sidenav.service'
import { Router } from '@angular/router';
import { StoreProvider } from '../core/providers/utils/store';

@Component({
  selector: 'admin-header',
  templateUrl: './admin-header.component.html',
  styleUrls: ['./admin-header.component.scss']
})
export class AdminHeaderComponent implements OnInit {

  rightSideNav: boolean;
  private location: Location;

  constructor(private sidenavService: SidenavService, private router: Router, private store: StoreProvider) { }

  ngOnInit() {
  }

  public toggleSidenav() {
    this.sidenavService.toggle().then(() => { });
  }

  public logout(event) {
    let isUserPresent = this.store.getStoreItem('user');
    if (isUserPresent) {
      this.store.removeStoreItem('user');
      this.store.removeStoreItem('parent-sidemenu');
    } else {
      console.log("no user present in session which is wrong.!!");
    }
    this.router.navigate(['/login']);

  }

}
