import { Component, OnInit } from '@angular/core';
import *  as moment from 'moment';

@Component({
  selector: 'admin-footer',
  templateUrl: './admin-footer.component.html',
  styleUrls: ['./admin-footer.component.scss']
})
export class AdminFooterComponent implements OnInit {

  currentYear = '';

  constructor() { }

  ngOnInit() {
    this.currentYear = moment().format('YYYY');
  }

}
