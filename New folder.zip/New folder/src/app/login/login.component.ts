import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { StoreProvider } from '../core/providers/utils/store';
import { MatSnackBar } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import *  as moment from 'moment';
import { Location } from '@angular/common';
import { ErrorMessageService } from 'src/app/core/services/error.message.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  // Local Variables
  user = { username: '', password: '' };
  loginForm: FormGroup;
  lang = '';
  currentYear = '';
  hide = true;
  
  private localeTexts = ['login.INVALID_LOGIN'];
  private location: Location;
  constructor(private router: Router, private store: StoreProvider, public snackBar: MatSnackBar, private translate: TranslateService, private errorMessageService: ErrorMessageService) { }

  ngOnInit() {
    this.lang = this.store.getStoreItem('qibLocale');
    this.localizeTexts();
    this.currentYear = moment().format('YYYY');
  }

  private localizeTexts() {
    this.translate.get(this.localeTexts)
      .subscribe(translations => {
        this.localeTexts = translations;
      });
  }
  changeLang() {
    let language = this.lang;
    if (this.lang === 'en') {
      language = 'ar';
    }
    else {
      language = 'en';
    }
    this.store.setStoreItem('qibLocale', language);
    location.reload();
  }

  loginSubmit() {
    console.log('succesfully loggedin');
    if (this.user.username === 'ppcadmin' && this.user.password === 'ppcadmin') {
      this.store.setStoreItem('user', JSON.stringify(this.user));
      this.router.navigate(['/ppcAdmin']);
    }
    else {
      // this.snackBar.open(this.localeTexts['login.INVALID_LOGIN'], undefined, {
      //   panelClass: ['snackbar-error']
      // });
      this.errorMessageService.error(this.localeTexts['login.INVALID_LOGIN']);
    }
  }
}
