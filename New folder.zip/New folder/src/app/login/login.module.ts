import { NgModule } from '@angular/core';
import { MaterialModule } from '../core/providers/utils/material-module';
import { RouterModule } from '@angular/router';
import { LOGINROUTES } from './login.routes';
import { LoginComponent } from './login.component';
import { FormsModule } from "@angular/forms";
import { SharedModule } from "../core/shared.module";
import { AdminFooterComponent } from 'src/app/admin-footer/admin-footer.component';

@NgModule({
  declarations: [
    LoginComponent,
    AdminFooterComponent
  ],
  imports: [
    SharedModule,
    RouterModule.forChild(LOGINROUTES)
  ],
  exports: [
    LoginComponent
  ]
})
export class LoginModule { }