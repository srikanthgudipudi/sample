import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CoreModule } from './core/core.module';
import { AppRoutingModule } from './app.routes';
import { SharedModule } from './core/shared.module';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AdminSideMenuComponent } from 'src/app/admin-sidemenu/admin-sidemenu.component';
import { LoginComponent } from 'src/app/login/login.component';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';
import { AdminModule } from './admin/admin.module'
import { CommonModule } from '@angular/common';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AdminModule,
    CommonModule,
    CoreModule.forRoot(),
    SharedModule,
    AppRoutingModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    Ng2GoogleChartsModule
  ],
  providers: [
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
