import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonUtilsProvider } from './providers/utils/utilities';
import { EncryptionProvider } from './providers/utils/encryption';
import { StoreProvider } from './providers/utils/store';
import { MaterialModule } from './providers/utils/material-module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AuthGuard } from "./providers/auth.gaurd";
import { MAT_SNACK_BAR_DEFAULT_OPTIONS } from "@angular/material";
import { ErrorMessageService } from 'src/app/core/services/error.message.service';
import { CorePipeModule } from './pipes/core.pipe.module';
import { PPCServicesModule } from './services/core.services.module';
import { HttpRestService } from 'src/app/core/providers/http.rest.api';

@NgModule({
  imports: [
    CommonModule,
    PPCServicesModule.forRoot(),
  ],
  declarations: [
  ],
  providers: [

  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MaterialModule,
    // Shared pipes across app
    CorePipeModule
  ]
})
export class CoreModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [CommonUtilsProvider,
        StoreProvider,
        EncryptionProvider,
        AuthGuard,
        HttpRestService,
        { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 3000 } }
      ]
    };
  }
}
