import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DateFormatPipe } from './ppc-date-format.pipe';
import { DateTimeFormatPipe } from './ppc-date-time-format.pipe';
import { OrderByPipe } from './order-by.pipe';
import { URLSafePipe } from './url-safe-pipe';

@NgModule({
    declarations: [DateTimeFormatPipe, DateFormatPipe, OrderByPipe, URLSafePipe],
    exports: [DateTimeFormatPipe, DateFormatPipe, OrderByPipe, URLSafePipe]
})
export class CorePipeModule { }
