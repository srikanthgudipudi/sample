import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'ppcDateTimeFormat'
})
export class DateTimeFormatPipe implements PipeTransform {
  transform(value: any, args?: any): any {
          if(value)
          return moment(value).format("YYYY-MM-DD hh:mm:ss");
          else return "";

  }
}