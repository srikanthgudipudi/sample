import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { HttpClient } from '@angular/common/http';
import { HttpRestService } from 'src/app/core/providers/http.rest.api';

@Injectable()
export class CustomerSearchService {

    constructor(private router: Router, public httpService: HttpRestService) {
    }

    getCustomerSearchList(): Observable<any> {
        console.log("inside the Service");
        console.log(this.httpService.getService('assets/data/search-list.json'));
        return this.httpService.getService('assets/data/search-list.json');
    }

}