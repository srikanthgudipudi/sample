import { NgModule, ModuleWithProviders, Optional, SkipSelf } from '@angular/core';
import { ErrorMessageService } from 'src/app/core/services/error.message.service';


/* Services */


@NgModule({
    imports: [
    ],
    exports: [
    ],
    declarations: [
    ]
})

export class PPCServicesModule {

    constructor( @Optional() @SkipSelf() _ppcCoreModule: PPCServicesModule) {
        if (_ppcCoreModule) {
            throw new Error(
                'PPCServicesModule is already loaded. Import it in the AppModule only');
        }
    }

    static forRoot(): ModuleWithProviders {
        return {
            ngModule: PPCServicesModule,
            providers: [ErrorMessageService]
        };
    }
}