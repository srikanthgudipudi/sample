import { Component, OnInit } from '@angular/core';

import { ErrorMessageService } from '../../../core/services/error.message.service';

@Component({
    selector: 'error-message',
    templateUrl: 'error.message.component.html'
})

export class ErrorMessageComponent {
    message: any;

    constructor(private errorMessageService: ErrorMessageService) { }

    ngOnInit() {
        this.errorMessageService.getMessage().subscribe(message => {
            //Timer needs to be set
            this.message = message;
        });
    }
}