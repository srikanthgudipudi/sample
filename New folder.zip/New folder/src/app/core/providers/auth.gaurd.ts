import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { StoreProvider } from './utils/store';
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private store: StoreProvider,
    private myRoute: Router) {
  }

  canActivate(next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    console.log(this.store.getStoreItem('user'));
    if (this.store.getStoreItem('user')) {
      return true;
    } else {
      this.myRoute.navigate(['login']);
      return false;
    }
  }
}
