import {Injectable} from '@angular/core';
import * as CryptoJS from 'crypto-js/crypto-js';
import {CommonVariablesProvider} from '../common-variables/common-variables';


/*
 *  Common Utilities provider
 *  @author TCS_Kochi
 */
@Injectable()
export class EncryptionProvider {

  constructor() {

  }
  // ---------------------------------------------- Encryption ----------------------------------------------------------

  encryptData(data) {
    return CryptoJS.AES.encrypt(data, CommonVariablesProvider.AESKEY);
  }

  decryptData(data) {
    return CryptoJS.AES.decrypt(data, CommonVariablesProvider.AESKEY).toString(CryptoJS.enc.Utf8);
  }

  encryptPassword(payLoad) {
    /*
     * Encrypt payload
     * @param {string}  plainPassword - user details to store
     * @return {}
     */

    // msgString is expected to be Utf8 encoded
    const key = CryptoJS.enc.Utf8.parse(CommonVariablesProvider.AESKEY);
    const iv = CryptoJS.lib.WordArray.random(16);
    const encrypted = CryptoJS.AES.encrypt(payLoad, key, {
      iv: iv
    });
    return iv.concat(encrypted.ciphertext).toString(CryptoJS.enc.Base64);
  }

  decryptPassword(payLoad) {
    /*
     * Decrypt payload
     * @param {string}  payLoad - Encrypted Payload
     * @return {}
     */

    const key = CryptoJS.enc.Utf8.parse(CommonVariablesProvider.AESKEY);
    const ciphertext = CryptoJS.enc.Base64.parse(payLoad);

    // split IV and ciphertext
    const iv = ciphertext.clone();
    iv.sigBytes = 16;
    iv.clamp();
    ciphertext.words.splice(0, 4); // delete 4 words = 16 bytes
    ciphertext.sigBytes -= 16;

    // decryption
    const decrypted = CryptoJS.AES.decrypt({ciphertext: ciphertext}, key, {
      iv: iv
    });
    return decrypted.toString(CryptoJS.enc.Utf8);
  }

  // --------------------------------------------------------------------------------------------------------------------
}
