import {Injectable} from '@angular/core';
import {EncryptionProvider} from './encryption';


/*
 *  Common Utilities provider
 *  @author TCS_Kochi
 */
@Injectable()
export class StoreProvider {

  constructor(private encrypt: EncryptionProvider) {

  }

  /**
   * Store information to local storage
   * @param key
   * @param value
   */
  setStoreItem(key, value) {
    sessionStorage.setItem(key, this.encrypt.encryptData(value));
  }

  /**
   * get information from localStorage
   * @param key
   */
  getStoreItem(key) {
    /*setTimeout(() => {
     var dataPromise = this.storage.get(key);
     let dataReturn = null;
     dataPromise.then((data) => {
     dataReturn = data
     return this.decryptPayload(dataReturn)
     });
     },200);*/
    if (sessionStorage.getItem(key)) {
      return this.encrypt.decryptData(sessionStorage.getItem(key));
    }
    return false;
  }

  /**
   * Remove store item
   * @param key
   */
  removeStoreItem(key) {
    sessionStorage.removeItem(key);
  }
}
