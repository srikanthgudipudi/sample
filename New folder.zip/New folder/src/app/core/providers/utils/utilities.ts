import {Injectable} from '@angular/core';


/*
 *  Common Utilities provider
 *  @author TCS_Kochi
 */
@Injectable()
export class CommonUtilsProvider {

  constructor() {

  }

  /**
   * Set lang attr & class to HTML tag
   * @param lang
   */
  setHtmlLang(lang) {
    let html = document.getElementsByTagName('html')[0];
    html.setAttribute('lang', lang);
    let direction = (lang === 'ar' ? 'RTL' : 'LTR');
    html.setAttribute('dir', direction);
    html.classList ? html.classList.add(lang) : html.className += ' ' + lang;
  }

  maskCreditCard(ccNo) {
    /**
     * Use this to achieve
     * 6 string mask eg: 1111 22xx xxxx 4444
     * @type {string}
     */
    // '1111222233334444'.match(/(\d{4})(\d{2})(\d{2})(\d{4})(\d{4})/)
    // '1111222233334444'.replace(/(\d{4})(\d{2})(\d{2})(\d{4})(\d{4})/, '$1 $2xx xxxx $5')
    return ccNo.replace(/(\d{4})(\d{4})(\d{4})(\d{4})/, '$1 xxxx xxxx $4');
  }
}
