
/**
   * Contains all image relative URL's used in applicaton
   * @returns URL String
   */
export const ImageConstants = {


}