import { environment } from '../../../../environments/environment';

/**
   * Contains all service URL's for Prepaid card application
   * @returns URL String
   */
export const UrlConstants = {

    BASE_URL: environment.baseUrl,

    AUTH: {
        LOGIN: '',
        LOGOUT: ''
    },

}