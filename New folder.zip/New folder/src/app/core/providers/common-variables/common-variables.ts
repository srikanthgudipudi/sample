export const CommonVariablesProvider = {
  AESKEY: 'Q!bP@ssw0rdPpc'
};
