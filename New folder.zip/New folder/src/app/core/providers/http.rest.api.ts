//core
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

//utils
import { UrlConstants } from './common-variables/url.constants';


import { Observable, of } from "rxjs";
import { map, catchError } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';



@Injectable()
export class HttpRestService {
    public url: string = '';
    public body: {} = {};
    public httpOptions: {};


    constructor(private httpClient: HttpClient) { }

    setHeaders() {
        let headers = new HttpHeaders();
        headers = headers.append('Content-Type', 'application/json');
        return this.httpOptions = {
            headers
        };
    }


    getService(apiURL: string) {
        this.url = UrlConstants.BASE_URL + apiURL;
        return this.httpClient.get(this.url, this.httpOptions)
            .pipe(map(
                (response: any) => response)
            // , catchError((e) => {
            //     throw _throw(this.customErrorHandler.handleError(e));
            // })
            );
    }

    postService(apiURL: string, data: {}) {

        this.url = UrlConstants.BASE_URL + apiURL;
        return this.httpClient.post(this.url, data, this.httpOptions)
            .pipe(
            map((response: any) => response)
            // , catchError((e) => {
            //     throw _throw(this.customErrorHandler.handleError(e));
            // })
            );
    }


    putService(apiURL: string, data: {}) {

        this.url = UrlConstants.BASE_URL + apiURL;

        return this.httpClient.put(this.url, data, this.httpOptions)
            .pipe(
            map((response: any) => response)
            // , catchError((e) => {
            //     throw _throw(this.customErrorHandler.handleError(e));
            // })
            );
    }

}