import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ErrorMessageService } from 'src/app/core/services/error.message.service';

@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.scss']
})
export class RegisterCustomerComponent implements OnInit {

  constructor(private router: Router, private translate: TranslateService, private errorMessageService: ErrorMessageService) {
  }


  ngOnInit() {

  }

  registerCustomer() {

  }

  navigateToSearch() {
    this.router.navigate(['/search']);
  }
}
