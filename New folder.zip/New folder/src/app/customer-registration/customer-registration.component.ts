import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customer-registration',
  templateUrl: './customer-registration.component.html',
  styleUrls: ['./customer-registration.component.scss']
})
export class CustomerRegistrationComponent implements OnInit {

  public childRoutes = [{ "path": "searchCustomer", "displayName": "SEARCH CUSTOMER" },
  { "path": "registerCustomer", "displayName": "REGISTER CUSTOMER" }];
  // Base Active Link will be search
  public activeChild = this.childRoutes[0];
  public formUrl = '';

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {

  }

  navigateToChild(link) {
    // console.log(link);
    // console.log(this.route);
    // console.log(this.route.snapshot.children);
    // this.formUrl = this.router.routerState.snapshot.url + link;
    // this.formUrl = '/ppcAdmin/customerRegistration/' + link;

    // As of now we are mentioning the Relative Parent Path, This will be replaced by activatedParentRoute.
    this.formUrl = '../customerRegistration/' + link;
    // console.log(this.router.navigate(['link'], { relativeTo: this.route }));
    // console.log(this.route.children[0]);
    // this.router.navigate(['formUrl'], { relativeTo: this.route.children[0]});
    // console.log(this.router.navigate(['../link']));
    this.router.navigate([this.formUrl], { relativeTo: this.route });
  }

}
