import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/providers/auth.gaurd';
import { LoginComponent } from 'src/app/login/login.component';
import { AdminModule } from './admin/admin.module'

const coreRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'ppcAdmin', loadChildren: './admin/admin.module#AdminModule', canActivate: [AuthGuard] },
  { path: '', component: LoginComponent },
  { path: '**', pathMatch: 'full', redirectTo: 'login' }
];

@NgModule({
  imports: [
    RouterModule.forRoot
      (coreRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
