import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent implements OnInit {
  //Local Variables  
  public childRoutes = [{ "path": "searchUser", "displayName": "SEARCH USER" },
  { "path": "createUser", "displayName": "CREATE USER" }];

  public activeChild = this.childRoutes[0];
  public formUrl = '';

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
  }


  navigateToChild(link) {
    this.formUrl = '../userRegistration/' + link;
    this.router.navigate([this.formUrl], { relativeTo: this.route });
  }

}
