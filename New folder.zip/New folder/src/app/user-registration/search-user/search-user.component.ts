import { Component, OnInit, ViewChild } from '@angular/core';
import { StoreProvider } from 'src/app/core/providers/utils/store';
import { MatTableDataSource, MatSort, MatPaginator, MatPaginatorModule, PageEvent, MatSnackBar } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { ErrorMessageService } from 'src/app/core/services/error.message.service';
import { FormGroup } from '@angular/forms';
import { CustomerSearchService } from 'src/app/core/services/customer-search.service';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-search-user',
  templateUrl: './search-user.component.html',
  styleUrls: ['./search-user.component.scss']
})
export class SearchUserComponent implements OnInit {

  private localeTexts = ['user.USR_LST', 'user.EDT', 'user.DEL', 'user.SRCH'];
  private location: Location;
  private user = { userName: '', emailId: '', phoneNumber: '' };
  private lang = '';
  private searchUserList: Observable<any>;
  private userList: any[];
  public responseFlag: boolean = false;

  // MAT Table Variables
  public dataSource;
  public displayedColumns = ['firstNameEng', 'phoneNumber', 'userName', 'edit', 'delete'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  public pageSize: number = 5;

  constructor(private store: StoreProvider, public snackBar: MatSnackBar, private translate: TranslateService, private customerSearchService: CustomerSearchService) {

  }

  ngOnInit() {
    this.lang = this.store.getStoreItem('qibLocale');
    this.localizeTexts();
  }

  searchUser() {
    if (this.user.userName != null) {
      this.responseFlag = true;
      this.dataSource = new MatTableDataSource(CUSTOMER_SEARCH_LIST);
      this.dataSource.paginator = this.paginator;
    }
  }

  private localizeTexts() {
    this.translate.get(this.localeTexts)
      .subscribe(translations => {
        this.localeTexts = translations;
      });
  }
}

export interface User {
  firstNameEng: string;
  userName: string;
  phoneNumber: string;
}

const CUSTOMER_SEARCH_LIST: User[] = [
  { firstNameEng: "Kishore", userName: "KISHOREAOE", phoneNumber: "66079241" },
  { firstNameEng: "Iva", userName: "IVA", phoneNumber: "33203755" },
  { firstNameEng: "Ire", userName: "IRE", phoneNumber: "5478566" },
  { firstNameEng: "Avire", userName: "AVIRE", phoneNumber: "66885652" },
];
