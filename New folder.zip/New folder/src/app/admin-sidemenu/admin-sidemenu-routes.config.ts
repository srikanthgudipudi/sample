export const ROUTES = [
    // Children to be Added After Multi Level Menu Implementation
    { path: 'dashboard', title: 'Dashboard', icon: 'fa-dashboard', children: null },
    { path: 'customerRegistration', title: 'Customer Registration', icon: 'fa-user', children: null },
    { path: 'userRegistration', title: 'User Registration', icon: 'fa-user-circle', children: null },
];
