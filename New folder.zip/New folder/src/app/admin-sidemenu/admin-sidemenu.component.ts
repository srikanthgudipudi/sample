import { AfterViewInit, Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ROUTES } from './admin-sidemenu-routes.config';
import { SidenavService } from '../core/services/sidenav.service'
import { MatSidenav } from '@angular/material'
import { HostListener } from "@angular/core";
import { Router, ActivatedRoute } from '@angular/router';
import { StoreProvider } from 'src/app/core/providers/utils/store';

@Component({
  selector: 'admin-sidemenu',
  templateUrl: './admin-sidemenu.component.html',
  styleUrls: ['./admin-sidemenu.component.scss']
})
export class AdminSideMenuComponent implements OnInit {
  // Local Variables
  private menuItems: object;
  private smallScreen: boolean;
  private user: string;

  @ViewChild('sidenav') public sidenav: MatSidenav;

  public isActive: string;
  public isMenuActivated;

  constructor(private sidenavService: SidenavService, private router: Router, private store: StoreProvider, private activatedRoute: ActivatedRoute) {
    this.menuItems = ROUTES;
  }

  @HostListener('window:resize', ['$event'])

  onResize(event) {
    this.configureSideNav()
  }

  configureSideNav() {
    this.smallScreen = window.innerWidth <= 800 ? true : false
    if (this.smallScreen) {
      this.sidenav.mode = "over"
      this.sidenav.opened = false
    } else {
      this.sidenav.mode = 'side'
      this.sidenav.opened = true
    }
  }

  // Will Think of better one later for Persisting the routerParent in ANGULAR ROUTER WAY
  onClickMenuItem(currentActivatedMenu) {
    if (currentActivatedMenu != '') {
      this.store.setStoreItem('parent-sidemenu', currentActivatedMenu);
      this.isMenuActivated = currentActivatedMenu;
    }
  }

  ngOnInit() {
    this.configureSideNav();
    this.sidenavService.setSidenav(this.sidenav);
    this.user = this.store.getStoreItem('user');
    this.isMenuActivated = this.store.getStoreItem('parent-sidemenu');
    // During initial login and load of dashboard, the FIRST dashboard should be actiavted.
    if (this.isMenuActivated === '' || this.isMenuActivated === false) {
      this.store.setStoreItem('parent-sidemenu', 'dashboard');
      this.isMenuActivated = 'dashboard';
    } else {
      // During Reload set to current activated route.
      let x = this.router.url.split("/");
      if (x.length) {
        let currentActivatedRoute = x[x.length - 1];
        this.store.setStoreItem('parent-sidemenu', currentActivatedRoute);
        this.isMenuActivated = currentActivatedRoute;
      }
      else{
        //Will Throw user out.
      }
    }
  }

}
