import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-queue',
  templateUrl: './approval-queue.component.html',
  styleUrls: ['./approval-queue.component.scss']
})
export class ApprovalQueueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
