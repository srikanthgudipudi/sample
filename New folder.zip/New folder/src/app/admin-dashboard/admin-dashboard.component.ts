import { Component, OnInit } from '@angular/core';
import { ErrorMessageService } from 'src/app/core/services/error.message.service';
import { ChartReadyEvent } from 'ng2-google-charts';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'ppc-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  //Local Variables
  public childRoutes = [{ "path": "approvalList", "displayName": "APPROVAL LIST" },
  { "path": "requestList", "displayName": "REQUEST LIST" }];
  public activeChild = this.childRoutes[0];
  public formUrl = '';

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
  }


  navigateToChild(link) {
    // Will be replaced with 'router.url', late
    this.formUrl = '../dashboard/' + link;
    this.router.navigate([this.formUrl], { relativeTo: this.route });
  }

}
