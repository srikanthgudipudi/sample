import { Component } from '@angular/core';
import { StoreProvider } from './core/providers/utils/store';
import { CommonUtilsProvider } from './core/providers/utils/utilities';
import { TranslateService } from '@ngx-translate/core';
import { Router, RouteConfigLoadStart, RouteConfigLoadEnd } from '@angular/router';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  loadingRouteConfig: boolean;

  constructor(private translate: TranslateService, private store: StoreProvider, private util: CommonUtilsProvider, private router: Router) {
    let qibLocale = store.getStoreItem('qibLocale');
    translate.setDefaultLang('en');
    // Fix for issue [Unless locale is changed in login screen, locale is not stored]
    if (!qibLocale) {
      qibLocale = 'en';
      store.setStoreItem('qibLocale', qibLocale);
    }
    else {
      this.translate.use(qibLocale);
    }
    // set html lang attr for localization
    util.setHtmlLang(qibLocale);
  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.router.events.subscribe(event => {
      if (event instanceof RouteConfigLoadStart) {
        this.loadingRouteConfig = true;
      } else if (event instanceof RouteConfigLoadEnd) {
        this.loadingRouteConfig = false;
      }
    });
  }
}
