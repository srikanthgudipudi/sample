import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user: any;
pswd: any;
error :any = false;
 hide = true;
 spin:boolean = false;
  constructor(private router: Router) { }

  ngOnInit() {
    this.spin = true;
  }

  login(){
    if(this.user ==="demo" && this.pswd ==="demo") {
      this.router.navigateByUrl('/Finance')
    }
    else {
      this.error = true;
       alert("Entered Username or passwod is incorrect")
    }
  }
  clear(){
    this.error  = false;
  }

}
