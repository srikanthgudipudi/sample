import { Component, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.css']
})
export class IncomeComponent implements OnInit {
 incomeForm: FormGroup;
 rimnumber: any;
  step = 0;
  constructor( private fb: FormBuilder, private router: Router) {

     this.incomeForm = fb.group({
      'paid_type': [null],
      'Tsalary': [null],
      'TAllowances': [null],
      'SAllowancesIncome': [null],
      'HAllowances': [null],
      'TravelAllowances': [null],
      'Others1': [null],
      'DFOthers1': [null],
      'MobileAllowances': [null],
      'SpecialAllowances': [null],
      'Others2': [null],
      'DOthers2' :[null],
      'Collateral': [null],
      'Obligation': [null],
      'ObligationF': [null],
      'ObligationAmount': [null],
      'ObligationPercentage' :[null]
     });
   }

  ngOnInit() {
  }

   setStep(index: number) {
    this.step = index;
  }

  nextStep() {
     // if (this.incomeForm.valid) {
      this.step++;
    // }
  }

  prevStep() {
    this.step--;
  }

}
