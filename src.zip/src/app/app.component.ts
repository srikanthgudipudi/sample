import { Component, OnInit, Inject, Injectable } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppService } from './app.service';
import { AppModule } from './app.module';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
// import {FootersComponent } from './';
import 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AppService]
})
export class AppComponent implements OnInit {
  title = 'app';
  error: any;
  data: any;
  panelOpenState: any = false;
  url: any;
  favoriteSeason: any;
  list: any;
  value: any;
  age: any;
  mnumber: any;
  resourcesLoaded: any = false;
  spin:boolean = false;
  constructor(private appService: AppService, translate: TranslateService,
    private router: Router,
    @Inject('apiEndPoint') public apiEndPoint: string, ) {

    this.url = '../assets/images/creditcards.jpg';
    translate.setDefaultLang('en');
    translate.use('en');


  }
  ngOnInit(): void {
   this.spin = true;
    this.radiochange();
    this.resourcesLoaded = true;

  }

  fileuploaderFileChange(files: FileList) {
    alert(files);
  }


  radiochange() {
    this.appService.serviceMethod()
      .subscribe(data => {

        this.list = data['data'];
        // console.log('vbhhhhhhhhh', this.list )
        // this.value = this.list.Name;
        // alert('Name'+ this.list.rimnumber);
        this.age = this.list.Age;
        this.mnumber = this.list.MobileNumber;
      },
      error => {

      });
  }

  onClickMe() {
    this.list = '';
    this.value = '';
    this.age = '';
    this.mnumber = '';
  }

  sampleMethod() {
    this.router.navigateByUrl('/login');
  }

  showConfig() {

  }
}
