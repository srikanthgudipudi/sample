import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footers',
  templateUrl: './footers.component.html',
  styleUrls: ['./footers.component.css']
})
export class FootersComponent implements OnInit {
//  tiles1 = [
//    {text: '', cols: 4, rows: 1, color: 'lightgreen'},
//   ];
  constructor() { }

  ngOnInit() {
  }

}
