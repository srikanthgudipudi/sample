import { Component, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
 accountForm: FormGroup;
 step = 0;
  constructor( private fb: FormBuilder, private router: Router) { 
    this.accountForm = fb.group({
      'paid_type': [null],
     });
  }

  ngOnInit() {
  }

   setStep(index: number) {
    this.step = index;
  }

  nextStep() {
     this.step++;
  }

  prevStep() {
    this.step--;
  }

}
