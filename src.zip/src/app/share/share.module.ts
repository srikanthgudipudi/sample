import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatCardModule} from '@angular/material/card';


@NgModule({
  imports: [
    CommonModule,
     FormsModule,
      ReactiveFormsModule
  ],
  declarations: [],
  exports: [FormsModule, CommonModule, ReactiveFormsModule, MatCardModule],
})
export class ShareModule { }
