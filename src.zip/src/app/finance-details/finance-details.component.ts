import { Component, OnInit } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NgModule } from '@angular/core';
import { SourcingService } from '../sourcing/sourcing.service';
import { AppService } from '../app.service';
import { FormBuilder, ReactiveFormsModule, FormGroup, Validators, FormsModule, NgForm } from '@angular/forms';
// import {Details} from '../sourcing/sourcing.component';
import {Directive} from '@angular/core';
import { Router } from '@angular/router';
import { IncomeComponent } from '../income/income.component';
@Component({
  selector: 'app-finance-details',
  //  directives : [IncomeComponent],
  templateUrl: './finance-details.component.html',
  styleUrls: ['./finance-details.component.css'],
  providers: [SourcingService],
 


})

@NgModule({
  imports: [MatToolbarModule],
  declarations: [],
  
})
export class FinanceDetailsComponent implements OnInit {
  model: Userd = new Userd();
  quickForm: FormGroup;
  step: any = 0;
  UserName: string = '';
  // details: any;
  list: any;
  applicationType: any;
  rimnumber: any;
  date: any;
  // Atype: any;
  // total: any
  // title: any;
  // gender: any;
  // age: any;
  qatar_id: any;
  spin: boolean = false;
  resourcesLoaded: any = true;
  model1: any = [];
  Apptype: any = '';

  constructor(private sourcingService: SourcingService, private appService: AppService, private fb: FormBuilder,
    private router: Router) {

    this.quickForm = fb.group({
      'UserName': [null],
      'Name': [null],
      'Atype': [null],
      'Rim': [null],
      'title': [null],
      'gender': [null],
      'age': [null],
      'QID': [null],
      'status': [null]
      // 'LastName' : [null, Validators.required],  
      // 'Address' : [null, Validators.compose([Validators.required, Validators.minLength(30), Validators.maxLength(500)])],  
      // 'DOB' : [null, Validators.required],  
      // 'Gender':[null, Validators.required],  
      // 'Blog':[null, Validators.required],  
      // 'Email':[null, Validators.compose([Validators.required,Validators.email])],  
      // 'IsAccepted':[null]  
    });
  }
  change() {
    this.model1 = [];
    if (this.Apptype) {
      // var step = 0
      // this.setStep(0)
    }
  }

  ngOnInit() {
    //  this.Apptype = 'sri';
    this.spin = true;
  }

  onFormSubmit(form: NgForm) {
    alert('onFormSubmit');
    console.log('======sumbit', form);
    // this.router.navigateByUrl('Source');
  }
  search() {
    this.appService.serviceMethod()
      .subscribe(data => {
        this.model = data['data'];
        this.model1 = this.model;
      },
      error => {

      });
  }
  clear() {
  this.model1 = [];
    // this.model = [];
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    alert('next');
    if (this.quickForm.valid) {
      this.step++;
    }
  }

  prevStep() {
    this.step--;
  }

}

export class Userd {
  public UserName = '';
  public password = '';
  public msg: string;
  public Name: string;
  public Atype = '';
  public Rim = '';
  public title = '';
  public gender = '';
  public age = '';
  public QID = '';
  public qatar_id = '';
}

