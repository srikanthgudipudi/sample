import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {
name: any;

config: SwiperOptions = {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            spaceBetween: 2,
            autoplayDisableOnInteraction: false,
            autoplay: 3000,
        };
  constructor() { }

  ngOnInit() {
  }
onClickMe() {
// alert('name' + this.name);
}
   "images":[  
      {  
         "name":"image1",
         "href":"../assets/images/background.jpg"
      },
      {  
         "name":"image2",
         "href":"http://east-nj1.photos.example.org/987/nj1-1234"
      },
      {  
         "name":"image3",
         "href":"http://east-nj1.photos.example.org/987/nj1-1234"
      },
      {  
         "name":"image4",
         "href":"http://east-nj1.photos.example.org/987/nj1-1234"
      }
   ]
}
