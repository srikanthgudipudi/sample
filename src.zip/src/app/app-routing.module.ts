import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AppComponent} from '../app/app.component';
import { RouterModule, Routes } from '@angular/router';
import { ApplicantComponent } from '../app/applicant/applicant.component';
import {FinanceDetailsComponent } from '../app/finance-details/finance-details.component';
import {SourcingComponent} from '../app/sourcing/sourcing.component';
import { LoginComponent } from '../app/login/login.component';
import { StatusComponent } from '../app/status/status.component';
import {PolicyComponent} from '../app/policy/policy.component';
import { CalculatorComponent } from '../app/calculator/calculator.component';
import { IncomeComponent } from '../app/income/income.component';
const routes: Routes = [
   { path: '',  redirectTo: '/login', pathMatch: 'full'},
  { path: 'Applicant', component: ApplicantComponent },
  { path : 'Finance' , component: FinanceDetailsComponent},
  { path : 'Source' , component: SourcingComponent},
  {path : 'login', component: LoginComponent},
  {path: 'status', component: StatusComponent},
   {path: 'policy', component: PolicyComponent},
   { path: 'calculate', component: CalculatorComponent },
   { path: 'income', component: IncomeComponent }
];

@NgModule({
  imports: [
    CommonModule,  RouterModule.forRoot(routes)
  ],
  declarations: [],
   exports: [ RouterModule ]
})
export class AppRoutingModule { }
