import { Component, OnInit } from '@angular/core';
import { SourcingService } from './sourcing.service';
@Component({
  selector: 'app-sourcing',
  templateUrl: './sourcing.component.html',
  styleUrls: ['./sourcing.component.css']
})
export class SourcingComponent implements OnInit {
  fileToUpload: File = null;
  list: any;
  files: any = [];
  step = 0;
  details: Details[];
  details1: any;
  fdata: any[] = [];
  final: any[];
  url: any = '';

  constructor(private sourcingService: SourcingService) { }

  ngOnInit() {
    this.search();
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }


  search() {
    this.sourcingService.postFile1().subscribe(details => {
      this.details1 = details['_body'];
      console.log('==========', this.details1);

    },
      error => {

      })
  }

  // To choose the files
  handleFileInput(files: FileList) {

    if (files && files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = reader.result;
      }

      this.fdata.push(files[0]);
      // this.uploadFileToActivity(this.fdata);
      // this.final = this.files;
    }
  }

  //  onFileChange(event) {
  //     let reader = new FileReader();
  //     if(event.target.files && event.target.files.length > 0) {
  //       let file = event.target.files[0];
  //       reader.readAsDataURL(file);
  //       reader.onload = () => {
  //         this.form.get('avatar').setValue({
  //           filename: file.name,
  //           filetype: file.type,
  //           value: reader.result.split(',')[1]
  //         })
  //       };
  //     }
  //   }


  // To send the files to the server
  uploadFileToActivity(data) {
    // alert('upload' +this.files[0].name);
    this.sourcingService.postFile(data).subscribe(data => {
      this.list = data['result'];
      // do something, if upload success
    }, error => {
      console.log(error);
    });
  }

} export class Details {
  rimnumber: Number;
  legal_id: any;
  legal_doc_name: any;
  firstnameeng: String;
  middlenameeng: String;
  lastnameeng: String;
  pobox: any;
  customeraddress1: any;
  country: any;
}
