import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SourcingService {

  constructor( private http: Http, private httpClient: HttpClient) { }

  postFile1() {
   // return this.http.get("../assets/staticjsonfiles/userdetails.json")
  //     .map(this.extractData)
  //     .catch(this.handleError);
   const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };
    // return this.http.get(this.apiEndpoint + 'api/v1/abc', httpOptions)
      return this.http.get("../assets/staticjsonfiles/userdetails.json")
      .map(this.extractData)
      .catch(this.handleError);
  }

  postFile(fileToUpload: File) {
   const endpoint = 'your-destination-url';
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    return this.httpClient.post(endpoint, formData)
        //  .post(endpoint, formData, { headers: yourHeadersConfig })
       .map(this.extractData)
      .catch(this.handleError);
}

  /*---- To Extract the data ----*/
  private extractData(res: Response) {
   const body = res;
    return body || {};
  }

  /*---- To handle the error page ----*/
  private handleError(error: Response | any) {
    return Observable.throw(error);
  }
}
