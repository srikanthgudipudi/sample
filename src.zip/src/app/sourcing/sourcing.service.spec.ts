import { TestBed, inject } from '@angular/core/testing';

import { SourcingService } from './sourcing.service';

describe('SourcingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SourcingService]
    });
  });

  it('should be created', inject([SourcingService], (service: SourcingService) => {
    expect(service).toBeTruthy();
  }));
});
