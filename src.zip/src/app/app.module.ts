import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FlexLayoutModule} from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatListModule } from '@angular/material/list';
import { MatChipsModule } from '@angular/material/chips';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';
import {
  MatButtonModule, MatMenuModule, MatToolbarModule, MatIconModule,
  MatCardModule, MatDatepickerModule, MatNativeDateModule, MatOptionModule,
  MatSlideToggleModule, ErrorStateMatcher, ShowOnDirtyErrorStateMatcher,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule
} from '@angular/material';
import {AppService } from './app.service';
import {SourcingService} from '../app/sourcing/sourcing.service';
import {MatSelectModule} from '@angular/material/select';
 import { HttpModule } from '@angular/http';
  import { HttpClientModule, HttpClient } from '@angular/common/http';
import { SourcingComponent } from './sourcing/sourcing.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { FinanceDetailsComponent } from './finance-details/finance-details.component';
import { AppRoutingModule } from './/app-routing.module';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatRadioModule} from '@angular/material/radio';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import * as config from './app.config';
import { LoginComponent } from './login/login.component';
import {FootersComponent } from './footers/footers.component';
import { StatusComponent } from './status/status.component';
import { FileUploaderModule } from "ng4-file-upload";
import { PolicyComponent } from './policy/policy.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { CalculatorComponent } from './calculator/calculator.component';
import { SwiperModule } from 'angular2-useful-swiper';
import { IncomeComponent } from './income/income.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { OthersComponent } from './others/others.component';
import {MatStepperModule} from '@angular/material/stepper';
// import {SourcingService } from '../app/sourcing/sourcing.service';
export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    SourcingComponent,
    ApplicantComponent,
    FinanceDetailsComponent,
    LoginComponent,
    FootersComponent,
    StatusComponent,
    PolicyComponent,
    CalculatorComponent,
    IncomeComponent,
    AccountDetailsComponent,
    OthersComponent
  ],
  imports: [
    BrowserModule,
    MatRadioModule,
    MatProgressSpinnerModule,
     MatTabsModule,
    FlexLayoutModule,
    FormsModule, ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatGridListModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatMenuModule,
    MatListModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatDatepickerModule,
    MatChipsModule,
    // MatDatepicker,
    MatNativeDateModule,
    // MatRadioModule,
    MatSelectModule,
    MatOptionModule,
    MatExpansionModule,
    AppRoutingModule,
    CommonModule,
    MatSidenavModule,
    FileUploaderModule,
    PdfViewerModule,
    SwiperModule,
    MatCheckboxModule,
    MatStepperModule,
    TranslateModule.forRoot({
       loader: {
                provide: TranslateLoader,
                useFactory: createTranslateLoader,
                deps: [HttpClient]
            }
    })

  ],
  exports: [FormsModule, CommonModule, MatToolbarModule, TranslateModule],
  providers: [AppService, SourcingService,
  {
      provide: 'apiEndPoint',
      useValue: config.API_END_POINT
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
