import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.css']
})
export class PolicyComponent implements OnInit {
pdfSrc: any;
imgfile: any = '';
  constructor() { }

  ngOnInit() {
    this.pdfSrc = "../../assets/Images/sample.pdf";
  }


onFileSelected(event){
  const files: FileList = event.target.files;

  this.imgfile = files[0];
   const pictype = this.imgfile.type;
  const pictype1 = this.imgfile.size;
  const pictype2 = this.imgfile.name;
  // alert('file selecte' +pictype + '' +pictype1 + '' + pictype2);
}
}
