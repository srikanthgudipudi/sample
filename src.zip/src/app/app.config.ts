import { environment } from '../environments/environment';
export const API_END_POINT = environment.apiUrl;