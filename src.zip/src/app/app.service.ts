import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';


@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient,
    @Inject('apiEndPoint') private apiEndpoint: string,
    private router: Router) { }

  // getConfig() {
  //   return this.http.get('')
  //   .this.extractData()
  //   .this.errorHandle();
  // }

  serviceMethod() {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    };
    // return this.http.get(this.apiEndpoint + 'api/v1/abc', httpOptions)
      return this.http.get("../assets/staticjsonfiles/userdetails.json")
      .map(this.extractData)
      .catch(this.handleError);
  }
  

  /*---- To Extract the data ----*/
  private extractData(res: Response) {
     const body = res;
    return body || {};
  }

  /*---- To handle the error page ----*/
  private handleError(error: Response | any) {
    return Observable.throw(error);
  }
}
